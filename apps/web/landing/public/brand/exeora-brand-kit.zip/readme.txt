Exeora brand assets
===================

24 files, drawn from one definition of the mark. The latest
set is always at https://exeora.dev/brand/.

Files
-----

exeora-mark*        The three tiles on their own.
exeora-wordmark*    The tiles plus the name, locked up.

  *-light           For dark backgrounds. #f4f5f6.
  *-dark            For light backgrounds. #0d0f11.
  *-on-brand        The tiles on the brand square, rounded. For icon slots.
  *-on-black        #ffffff on #000000, full bleed, for listings
                    that ask for exactly that.

  exeora-mark.svg and exeora-wordmark.svg carry currentColor instead of a
  colour, for embedding in something that sets its own.

Using them
----------

Keep clear space of at least the width of one tile on every side. Do not
recolour, rotate, stretch, outline, add effects to, or box in the mark, and do
not rebuild the wordmark by setting the name in another face.

Licence
-------

Exeora's source is AGPL-3.0-only. The name and the mark are not: they are
Exeora's, and this kit is permission to use them to refer to Exeora, in
editorial writing, integration listings and documentation. It is not permission
to suggest Exeora endorses or is affiliated with anything.

Inter and JetBrains Mono are licensed under the SIL Open Font License 1.1 and
are not included here.

Questions: hello@exeora.dev
